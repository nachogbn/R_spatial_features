# README 

Este repositorio contiene el material del módulo *Generación de visores de datos espaciales con R* dentro de la Asignatura ***Ciclo de Gestión del Dato: Ecoinformática*** del Máster Universitario en Conservación, Gestión y Restauración de la Biodiversidad, de la Universidad de Granada. 

## <img src='img/display-solid.svg' width='25'> [Diapositivas](https://ajpelu.github.io/teach_spatial_viewers/slides.html)

## <img src='img/github.svg' width='30'> [Repo](https://github.com/ajpelu/teach_spatial_viewers_shannon) con ejemplo 

This repository is licensed as Creative Commons Attribution 4.0 ([CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)). Mas información [aquí](/LICENSE). Cualquiera puede utilizar el contenido del repositorio citando lo siguiente: 
